package ImgPckg;

import java.io.File;

// Class to update file tags and current/Selected file pointer
public class Tags {
    public static String tag;
    public static File SelectedFile;
}
